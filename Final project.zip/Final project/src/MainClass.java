///*
// * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
// * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
// */
//
///**
// *
// * @author 20106
// */
//import java.util.*;
//public class MainClass {
//    static Scanner input = new Scanner(System.in);
//    
//    public static int choseActor(){
//        int actorType;
//        System.out.println("");
//        System.out.println("Select your type : ");
//        System.out.println("1) Employee ");
//        System.out.println("2) Passenger ");
//        System.out.println("3) Exit ");
//        System.out.print("what is your option -->  ");
//        actorType = input.nextInt();
//        return actorType;
//    }
//    
//    public static int selectEmployeeFunctions(){
//        int result;
//        System.out.println("                                                                              Welcome                  ");
//        System.out.println("Please select one of the following options : ");
//        System.out.println("1) Add Flight ");
//        System.out.println("2) Delete Flight ");
//        System.out.println("3) Search For a Flight ");
//        System.out.println("4) Update Flight ");
//        System.out.println("5) Display All Flights ");   
//        System.out.println("6) Add Employee : ");
//        System.out.println("7) Delete Employee : ");
//        System.out.println("8) Generate report : ");
//        System.out.println("9) display Employees : ");
//        System.out.println("10. Log out");
//        System.out.print("what is your option -->  ");
//        result = input.nextInt();
//        return result;
//    }
//    
//    public static int selectPassengerFunctions(){
//        int result;
//        System.out.println("                                                                              Welcome                  ");
//        System.out.println("Please select one of the following options : ");
//        System.out.println("1) Make booking ");
//        System.out.println("2) Cancel Booking ");
//        System.out.println("3) Update Booking ");
//        System.out.println("4) Search For Booking ");
//        System.out.println("5) Create account "); 
//        System.out.println("6) Delete account "); 
//        System.out.println("7) Manage account "); 
//        System.out.println("8) Display account details ");
//        System.out.println("9) Make Enquiry "); 
//        System.out.println("10) Delete Enquiry "); 
//        System.out.println("11) Log out ");
//        System.out.print("what is your option -->  ");
//        result = input.nextInt();
//        return result;
//    }
//    
//    public static void main(String[] args) {
//        int chosedOperation;
//        int accountId;
//        int actorType;
//        
//        Flight F = new Flight();
//        Employee E = new Employee();
//        Passenger P = new Passenger();
//        Booking b;
//        
//        do{
//            actorType = choseActor();
//        
//            if(actorType == 1){
//                do {
//                    chosedOperation = selectEmployeeFunctions();
//                    if(chosedOperation == 1){
//                        System.out.println("how many Flights you want to add ? : ");
//                        int add = input.nextInt();
//                        for(int i = 0; i < add; i++){
//                            Flight F5 = new Flight();
//                            F.AddFlight(F5);  
//                        }
//                        System.out.println("");
//                    }
//
//                    else if(chosedOperation == 2){           
//                        System.out.println("Enter the Flight number you want to delete : ");
//                        int Del = input.nextInt();
//                        F.RemoveFllight(Del);
//                    }
//
//                    else if(chosedOperation == 3){           
//                        System.out.println("Enter the Flight number you are searching for : ");
//                        int F_S=input.nextInt();
//                        F.SearchFlight(F_S);
//                    }
//
//                    else if(chosedOperation == 4){           
//                        System.out.println("Enter the Flight number you want to edit : ");
//                        int Up=input.nextInt();
//                        F.EditFlight(Up);
//                    }
//
//                    else if(chosedOperation == 5){
//                        System.out.println("the flights in the system are : " + Flight.Flights.size());
//                        System.out.println(" ");
//                        for (int i = 0; i < Flight.Flights.size(); i++){
//                            System.out.println((i+1)+") "+Flight.Flights.get(i));
//                        }
//                    }
//
//                    else if(chosedOperation == 6){
//                        Employee E1=new Employee();
//                        E.AddAcc(E1);
//                    }
//
//                    else if(chosedOperation == 7){
//                        System.out.println("Enter the ID of employee you want to delete : ");
//                        accountId=input.nextInt();
//                        E.RemoveAcc(accountId);
//                    }
//
//                    else if(chosedOperation == 8){
//                        //generate report
//                    }
//
//                    else if(chosedOperation == 9){
//                        E.display();
//                    }
//                } while(chosedOperation != 10);
//            }
//            else if(choseActor() == 2){ 
//                chosedOperation = selectPassengerFunctions();
//                do{
//                    if(chosedOperation == 1){
//                        int passengerId;
//                        System.out.print("Enter your ID: ");
//                        passengerId = input.nextInt();                        
//                        b = new Booking(passengerId);
//                    }
//                    else if (chosedOperation == 2){ //cancel booking
//                        int bookingID, passengerId;
//                        System.out.print("Enter Your ID: ");
//                        passengerId = input.nextInt();
//                        System.out.print("Enter Booking ID: ");
//                        bookingID = input.nextInt();
//                        Booking.cancelBooking(bookingID, passengerId);
//                    }
//                    else if(chosedOperation == 3){ //Update Booking
//                        int bookingID;
//                        System.out.println("Enter the booking ID: ");
//                        bookingID = input.nextInt();
//                        Booking.manageBooking(bookingID);
//                    }
//                    else if (chosedOperation == 4){  //Display booking details
//                        int bookingID;
//                        System.out.print("Enter booking ID: ");
//                        bookingID = input.nextInt();
//                        Booking.displayBooking(bookingID);
//                    }
//                    
//                    
//                    else if (chosedOperation == 5){  
//                        E.display();Passenger P1 = new Passenger();
//                        P.AddAcc(P1);
//                    }
//                    else if (chosedOperation == 6){  
//                        System.out.println("Enter the passenger Id for the passenger you want to delete : ");
//                        accountId=input.nextInt();
//                        P.RemoveAcc(accountId);
//                    }
//                    else if (chosedOperation == 7){  
//                        System.out.println("Enter the passenger Id for the passenger you want to update : ");
//                        accountId=input.nextInt();
//                        Passenger.ManageAccount(accountId); 
//                    }
//                    else if (chosedOperation == 8){  
//                         P.display();
//                    }
//
//                    else if (chosedOperation == 9){  /*if he choose 4 the display Employees function will call from the employee class  */
//                        System.out.println("please add your inquiry title");
//                        String InquiryTitle=input.next();
//                        System.out.println("please add your inquiry ID");
//                        int ID=input.nextInt();
//                        System.out.println("please add your inquiry type");
//                        String InquiryType=input.next();
//                        System.out.println("please add your inquiry date");
//                        int InquiryDate=input.nextInt();
//                        System.out.println("please add your inquiry description");
//                        String InquiryDescription=input.next();
//                        Inquiry I =new Inquiry(ID, InquiryTitle, InquiryType, InquiryDate,InquiryDescription);
//                        Inquiry.getArr2().add(I);
//                    }
//                    else if (chosedOperation == 10){  /*if he choose 4 the display Employees function will call from the employee class  */
//                        System.out.println("please enter the inquiry ID you want to delete ");
//                                int ID =input.nextInt();
//                                Inquiry I1=new Inquiry();
//                                I1.removeInquiry(ID);
//                    }
//
//                }while(chosedOperation != 11); /*if he choose 5 he will get out from employee functions */          
//            }
//            
//        }while(choseActor() != 3); 
//    }   
//    
//}
