/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author 20106
 */

import java.util.*;

// person class is a superclass for the subclasses employee and passenger 
//person is an abstract class because it has abstract methods
public abstract class Person {
    private Long NationalID;
    private String FullName;
    private  int age;
    private String gender;
    protected long PhoneNumber; 
    private String email;
    private String password;
    //constructor to intialize the attributes
    public Person(Long NationalID, String FullName, int age, String gender, long PhoneNumber, String email, String password) {
        this.NationalID = NationalID;
        this.FullName = FullName;
        this.age = age;
        this.gender = gender;
        this.PhoneNumber = PhoneNumber;
        this.email = email;
        this.password = password;
    }
//Defulat constructors 
    public Person() {
    }
    
    
//setters and getters for private attributes
    public long getNationalID() {
        return NationalID;
    }

    public void setNationalID(long NationalID) {
        this.NationalID = NationalID;
    }

    public String getFullName() {
        return FullName;
    }

    public void setFullName(String FullName) {
        this.FullName = FullName;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public long getPhoneNumber() {
        return PhoneNumber;
    }

    public void setPhoneNumber(long PhoneNumber) {
        this.PhoneNumber = PhoneNumber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
    
    public abstract void display( );//display is an abstract method in the superclass person and will be overriden in the subclasses employee and passenger
    public abstract void AddAcc(Person P);//addperson is an abstract method in the superclass person and must be overriden in the subclasses employee and passenger 
    public abstract void RemoveAcc(int ID);//addperson is an abstract method in the superclass person and must be overriden in the subclasses employee and passenger 
    @Override
    public String toString() { // tostring function is used to display all the attributes
        return "Person{" + "NationalID=" + NationalID + ", FullName=" + FullName + ", age=" + age + ", gender=" + gender + ", PhoneNumber=" + PhoneNumber + '}';
    }
    
}
    

