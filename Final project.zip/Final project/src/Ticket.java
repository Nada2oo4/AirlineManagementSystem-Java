/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author 20106
 */
import java.util.*;
import java.time.LocalDate;

public class Ticket {
    Scanner input = new Scanner(System.in);
    
    private int ticketID;   //
    private String type;
    private String origin;
    private String destination;
    private int seatNum;  
    private LocalDate date;  //
    private String startTime;
    private String endTime;
    private float price;   
    private int flightNumber;
    private int bookingId;
    public static int ticketsCounter;  
    Flight f;
    public static ArrayList<Ticket> allTickets = new ArrayList<>();   // This array list for storing all the tickets in the application
    
    public Ticket(){   // Default constructor
        
    }
    
    public Ticket(String type, String origin, String destination, int seatNum, String startTime, String endTime, int fightNumber, int bookingId) {   // Parametrized constructor
        ticketsCounter++;
        ticketID = ticketsCounter;
        this.type = type;
        this.origin = origin;
        this.destination = destination;
        this.seatNum = seatNum;
        this.date = LocalDate.now();
        this.startTime = startTime;
        this.endTime = endTime;
        this.flightNumber = fightNumber;
        this.bookingId = bookingId; 
        if(f.SearchFlight(fightNumber)){
            f = Flight.GetFlight(flightNumber);
            price = f.getTicketPrice();
        }
        allTickets.add(this);
    }

    public int getTicketID() {
        return ticketID;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getOrigin() {
        return origin;
    }

    public void setOrigin(String origin) {
        this.origin = origin;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public int getSeatNum() {
        return seatNum;
    }

    public void setSeatNum(int seatNum) {
        this.seatNum = seatNum;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getFlightNumber() {
        return flightNumber;
    }

    public void setFlightNumber(int flightNumber) {
        this.flightNumber = flightNumber;
    }

    public int getBookingId() {
        return bookingId;
    }

    public void setBookingId(int bookingId) {
        this.bookingId = bookingId;
    }
       
    public void addTicket(Ticket t){  // This function Takes an object of type Ticket and adds it to the array list 'allTickets'
        allTickets.add(t);
    }
    
    public void deleteTicket(int ticketid){    // This function takes an id of a ticket object and search for it in the array list 'allTickets' to remove this object from the array list
        for(int i = 0; i < allTickets.size(); i++){
            if(allTickets.get(i).ticketID == ticketid)
                allTickets.remove(i);
        }
    }

    public static Ticket getTicket(int id){
        for(int i = 0; i < allTickets.size(); i++){
            if(allTickets.get(i).ticketID == id)
                return allTickets.get(i);
        }
        
        return null;
    }
    
    
    
//    public int searchTicket(String start, String end){   // this function takes the origin city and the destination of a specific route and return all the tickets that are booked in that route
//        for(int i = 0; i < allTickets.size(); i++){
//            if(allTickets.get(i).origin == start && allTickets.get(i).destination == end)
//                return allTickets.get(i).bookingId;
//        }
//        return 0;
//    }
    
    
    
}
