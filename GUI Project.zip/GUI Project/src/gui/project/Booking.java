/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gui.project;
/**
 *
 * @author 20106
 */
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;
import javax.swing.*;

public class Booking {
    static Scanner input = new Scanner(System.in);
    
    private int bookingID;     //  
    private int numberOfTickets; 
    private String payementMethod;
    private LocalDate bookingDate;  // 
    private float totalAmount;
    private int passengerId; // the booking will be added to the history bookings of this passenger
    private int flightNumber;  //
    public static int bookingCounter; // this attribute for setting the booking id 
    private Passenger p; //
    Ticket t;
    private Flight f;  //
    
    public static ArrayList<Booking> allBookings = new ArrayList<>(); //This array list for storing all the bookings that done in the application
    public ArrayList<Ticket> tickets = new ArrayList<>(); //This array list for storing all the tickets in each booking 
    
    public Booking(){
        
    }
    
    public Booking(int passengerId, String origin, String destination, String start, String end, String date, int flightNum) {  // parametrized constructor
        bookingCounter++;
        bookingID = bookingCounter;
        bookingDate = LocalDate.now();
        this.passengerId = passengerId;
        this.flightNumber = flightNum;
        
        try{
            p = Passenger.SearchforPassenger(passengerId);
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, "Incorrect Passenger ID");
        }
        
        try{
            f = Flight.GetFlight(flightNumber);
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, "Flight doesn't exist");
        }
    }
    
    public int getBookingID() {
        return bookingID;
    }

    public int getNumberOfTickets() {
        return numberOfTickets;
    }

    public String getPayementMethod() {
        return payementMethod;
    }

    public void setPayementMethod(String payementMethod) {
        this.payementMethod = payementMethod;
    }

    public LocalDate getBookingDate() {
        return bookingDate;
    }

    public void setBookingDate(LocalDate bookingDate) {
        this.bookingDate = bookingDate;
    }
    
    public float getTotalAmount() {
        return totalAmount;
    }

    public int getPassengerId() {
        return passengerId;
    }

    
//    public ArrayList<Ticket> getTickets() {
//        return tickets;
//    }
//
//    public void setTickets(ArrayList<Ticket> tickets) {
//        this.tickets = tickets;
//    }

    public int getFlightNumber() {
        return flightNumber;
    }
    
    public void makePayement(String payementMethod){
        this.payementMethod = payementMethod;
        addBooking(this);
    }

    public static void Book(int flightNum, int bookingID, String type, int seatNum){  // this function for the process of booking
        Flight f;
        Ticket t;
        f = Flight.GetFlight(flightNum);
        Booking b;
        b = Booking.getBooking(bookingID);
        f.setSeat(seatNum, type);
        t = new Ticket(type, f.getStartPoint(), f.getDestination(), seatNum, f.getLeaveDate(), f.getArriveDate(), f.getFlightNumber(), b.getBookingID());
        b.tickets.add(t);
        b.numberOfTickets++;

        if(type.equals("Economy Class"))
            b.totalAmount += t.getPrice();
        else if(type.equals("First Class"))
            b.totalAmount += (t.getPrice() + 500);
        else if(type.equals("Buisness Class"))
            b.totalAmount += (t.getPrice() + 300);
    }
    
    public static boolean checkBooking(int id){
        for(int i = 0; i < allBookings.size(); i++){
            if(allBookings.get(i).bookingID == id)
                return true;
        }
        return false;
    }
    
    public static Booking getBooking(int id){
        
        for(int i = 0; i < allBookings.size(); i++){
            if(allBookings.get(i).bookingID == id)
                return allBookings.get(i);
        }

        return null;
    }
        
    private void addBooking(Booking b){
        allBookings.add(b);
        p.History.add(b);
        JOptionPane.showMessageDialog(null, "Booked Successfully");
        
    }
    
    public static void cancelBooking(int bookingId, int passengerId){
        Passenger passenger = Passenger.SearchforPassenger(passengerId);
        Booking b = getBooking(bookingId);
        Flight flight = Flight.GetFlight(b.getFlightNumber());
        for(int i = 0; i < b.tickets.size(); i++){
            flight.setSeatEmpty(b.tickets.get(i).getSeatNum(), b.tickets.get(i).getType());
            Ticket.allTickets.remove(b.tickets.get(i));   //  !!!!!!!! use removeTcket 
        }
        JOptionPane.showMessageDialog(null, "Booking canceled successfully");
        
        allBookings.remove(b);
        passenger.History.remove(b);   
    }
    
    public void manageBooking(int bookingId){
        Flight flight;
        Ticket ticket;
        int seatNum=0;
        String ticketType="";
        if(checkBooking(bookingId)){
            int answer;
            Booking b = getBooking(bookingId);
            flight = Flight.GetFlight(b.getFlightNumber());
            System.out.println("What changes do you want to make?");
            System.out.println(" 1. Add ticket");
            System.out.println(" 2. Remove ticket");
            System.out.println(" 3. Change payement method");
            System.out.println(" 4. Cancel booking");
            answer = input.nextInt();
            if(answer == 1){
                Book(flight.getFlightNumber(),bookingId,ticketType,seatNum );
                System.out.println("Booking updated successfully");
            }
            else if(answer == 2){
                int ticketId;
                System.out.print("Enter ticket id: ");
                ticketId = input.nextInt();
                ticket = Ticket.getTicket(ticketId);
                Ticket.allTickets.remove(ticket);
                b.tickets.remove(ticket);
                b.numberOfTickets--;
                System.out.println("Booking updated successfully");
            }
            else if(answer == 3){
                int method;
                System.out.println("Chose the payement method: ");
                System.out.println(" 1. Visa");
                System.out.println(" 2. Cash");
                method = input.nextInt();
                if(method == 1)
                    b.setPayementMethod("Visa");
                else if(method == 2)
                    b.setPayementMethod("Cash");
                System.out.println("Booking updated successfully");
            }
            else if(answer == 4){
                cancelBooking(bookingId, b.getPassengerId());
            }
        }
        
        System.out.println("");
    }
    
    public static void displayBooking(int bookingId){
        Booking b = Booking.getBooking(bookingId);
        System.out.print("Booking ID: ");
        System.out.println(b.getBookingID());
        System.out.print("Number of tickets: ");
        System.out.println(b.getNumberOfTickets());
        System.out.print("Payement Method: ");
        System.out.println(b.getPayementMethod());
        System.out.print("Booking date: ");
        System.out.println(b.getBookingDate());
        System.out.print("Total amount: ");
        System.out.println(b.getTotalAmount());
        System.out.print("Passenger ID: ");
        System.out.println(b.getPassengerId());
        System.out.print("Flight Number: ");
        System.out.println(b.getFlightNumber());
    }
    
    public void viewHistoryBookings(){
        
        System.out.println("This is the history of bookings of this id: ");
        System.out.println(p.History);
    }
}
