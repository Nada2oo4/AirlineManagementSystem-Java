/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gui.project;
/**
 *
 * @author 20106
 */
import java.util.*;

public class Employee extends Person {
    public static ArrayList<Employee> Emplyees = new ArrayList<>(); // static arraylist shared among all instances
    private int Ssn;
    private int Salary;
//constructors to intialize the attributes
    public Employee(int Ssn, int Salary, long NationalID, String FullName, int age, String gender, long PhoneNumber, String Email, String password) {
        super(NationalID, FullName, age, gender, PhoneNumber, Email, password);
        this.Ssn = Ssn;
        this.Salary = Salary;
    }


//Defulat constructors 

    public Employee() {
    }
    
       //setters and getters for the employee private attributes 


    public int getSsn() {
        return Ssn;
    }

    public void setSsn(int Ssn) {
        this.Ssn = Ssn;
    }

    public int getSalary() {
        return Salary;
    }

    public void setSalary(int Salary) {
        this.Salary = Salary;
    }

    
   public String GenerateReport(){
       return "report:";
   }
 
    
    //override add person function from class person to addperson type employee
    @Override
    public void AddAcc(Person P) {
        Employee emp =  (Employee) P;
        Scanner input = new Scanner(System.in);  
        System.out.println("enter your SSN");
        int ssn=input.nextInt();
        System.out.println("enter your Salary");
        int salary=input.nextInt();
        System.out.println("enter your NationalID");
        long NID=input.nextLong();
        System.out.println("enter your FullName");
        input.nextLine();
        String FNAME=input.nextLine();
        System.out.println("enter your age");
        int A=input.nextInt();
        System.out.println("enter your gender");
        String G =input.next();
        System.out.println("enter your PhoneNumber");
        int PhoneNUM=input.nextInt();
        emp.setAge(A);
        emp.setFullName(FNAME);
        emp.setGender(G);
        emp.setNationalID(NID);
        emp.setPhoneNumber(PhoneNUM);
        emp.setSalary(salary);
        emp.setSsn(ssn);
        System.out.println("added successfully");
        Emplyees.add(emp);

    }
           //override add person function from class person to removeperson type employee

    @Override
    public void RemoveAcc(int ssn){
        boolean b = true;
        for (int i=0; i<Emplyees.size(); i++)
        {          
            if (Emplyees.get(i).getSsn() == ssn){
                System.out.println(Employee.Emplyees.get(i));
            Emplyees.remove(i);
            System.out.println("Emolyee is removed successfully");
            System.out.println("");
            b = false;
            }
        }
        if (b)
            System.out.println("the employee is not found");
     }
        //override display function from person class to display all employees int the array list
    @Override
    public void display( ){ 
        System.out.println("this is the list of Employees");
        System.out.println(Emplyees);
    }
}
