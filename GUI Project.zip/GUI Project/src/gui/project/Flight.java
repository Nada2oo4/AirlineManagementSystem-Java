/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gui.project;
/**
 *
 * @author 20106
 */
import java.util.*;
public class Flight {
    private int FlightNumber;
    private int FlightCapacity;
    private int NumberOfPassengers;
    private String StartPoint;
    private String Destination;                               /*  this is the attributes of the class */
    private String Duration;
    private String LeaveDate;
    private String LeaveTime;
    private String ArriveDate;
    private String ArriveTime;
    private String AirportCode;
    private float ticketPrice;
    public static ArrayList<Flight>Flights=new ArrayList<>();  /* array list for all Flights*/

    Scanner sc =new Scanner(System.in); /* object cs from scanner to get values from user*/
    int F_Num;
    int F_Capacity;
    int F_Passengers;
    int SFN;
    String S_Point;
    String Dist;
    String Dur;                 /* values created which we will use it inside functions*/
    String L_Date;
    String L_Time;
    String A_Date;
    String A_Time;
    String A_P_Code;
    public boolean [] economySeats = new boolean [FlightCapacity / 2];  /* array of boolean to set the state of the economy seats */
    public boolean [] firstClassSeats = new boolean [FlightCapacity / 4];/* array of boolean to set the state of the first cass seats */
    public boolean [] buisnessSeats = new boolean [FlightCapacity / 4];/* array of boolean to set the state of the buisness seats */
    
    
    public void setSeat(int seatnum, String type){  /* this function is to make the booked seats unavailable*/
        if(type.equals("Economy Class") )
            economySeats[seatnum - 1] = true;
        else if (type.equals("First Class"))
            firstClassSeats[seatnum - 1] = true;      
        else if (type == "Buisness Class")
            buisnessSeats[seatnum - 1] = true;
    }    
    public void setSeatEmpty(int seatnum, String type){ /* this function is to make the cancelled seats unavailable*/
        if(type == "Economy Class")
            economySeats[seatnum - 1] = false;
        else if (type == "First Class")
            firstClassSeats[seatnum - 1] = false;      
        else if (type == "Buisness Class")
            buisnessSeats[seatnum - 1] = false;
    }
    
    public void displaySeats(String type){   /* this function is to display all available*/
        if(type == "Economy Class"){
            for(int i = 0; i < economySeats.length; i++){
                if(economySeats[i] == false){
                    System.out.print((i+1) + ",  ");
                }
            }
            System.out.println("");
        }
        else if(type == "First Class"){
            for(int i = 0; i < firstClassSeats.length; i++){
                if(firstClassSeats[i] == false){
                    System.out.print((i+1) + ",  ");
                }
            }
            System.out.println("");
        }
        else if(type == "Buisness Class"){
            for(int i = 0; i < buisnessSeats.length; i++){
                if(buisnessSeats[i] == false){
                    System.out.print((i+1) + ",  ");
                }
            }
            System.out.println("");
        }
        
    }
     

    
//constructors to intialize the attributes
    public Flight(int FlightNumber, int FlightCapacity,int NumberOfPassengers, String StartPoint, String Destination, String Duration, String LeaveDate, String LeaveTime, String ArriveDate, String ArriveTime, String AirportCode, float ticketPrice) {
        this.FlightNumber = FlightNumber;
        this.FlightCapacity = FlightCapacity;
        this.NumberOfPassengers=NumberOfPassengers;
        this.StartPoint = StartPoint;
        this.Destination = Destination;
        this.Duration = Duration;
        this.LeaveDate = LeaveDate;
        this.LeaveTime = LeaveTime;
        this.ArriveDate = ArriveDate;
        this.ArriveTime = ArriveTime;
        this.AirportCode = AirportCode;
        this.ticketPrice = ticketPrice;
       // this.Flights=Flights;
    }
    
    
    
//Defulat constructors 
    public Flight() {
        //this()
        FlightNumber = 0;
        FlightCapacity = 0;
        NumberOfPassengers = 0;
        StartPoint = " ";
        Destination = " ";
        Duration = " ";
        LeaveDate = " ";
        LeaveTime = " ";
        ArriveDate = " ";
        ArriveTime = " ";
        AirportCode = " ";
        ticketPrice = 0;
    }
    
    
    
    //setters and getters for the private attributes
    public float getTicketPrice() {
        return ticketPrice;
    }

    public void setTicketPrice(float ticketPrice) {
        this.ticketPrice = ticketPrice;
    }
    
    public void setFlightNumber(int FlightNumber) {
        this.FlightNumber = FlightNumber;
    }

    public void setFlightCapacity(int FlightCapacity) {
        this.FlightCapacity = FlightCapacity;
    }
    
    public void setNumberOfPassengers(int NumberOfPassengers) {
         this.NumberOfPassengers = NumberOfPassengers;
    }

    public void setStartPoint(String StartPoint) {
        this.StartPoint = StartPoint;
    }

    public void setDestination(String Destination) {
        this.Destination = Destination;
    }

    public void setDuration(String Duration) {
        this.Duration = Duration;
    }

    public void setLeaveDate(String LeaveDate) {
        this.LeaveDate = LeaveDate;
    }

    public void setLeaveTime(String LeaveTime) {
        this.LeaveTime = LeaveTime;
    }

    public void setArriveDate(String ArriveDate) {
        this.ArriveDate = ArriveDate;
    }

    public void setArriveTime(String ArriveTime) {
        this.ArriveTime = ArriveTime;
    }

    public void setAirportCode(String AirportCode) {
        this.AirportCode = AirportCode;
    }

//    public void setFlights(ArrayList<Flight> Flights) {
//        this.Flights = Flights;
//    }

    public int getFlightNumber() {
        return FlightNumber;
    }

    public int getFlightCapacity() {
        return FlightCapacity;
    }

    public String getStartPoint() {
        return StartPoint;
    }

    public String getDestination() {
        return Destination;
    }

    public String getDuration() {
        return Duration;
    }

    public String getLeaveDate() {
        return LeaveDate;
    }

    public String getLeaveTime() {
        return LeaveTime;
    }

    public String getArriveDate() {
        return ArriveDate;
    }

    public String getArriveTime() {
        return ArriveTime;
    }

    public String getAirportCode() {
        return AirportCode;
    }

    public int getNumberOfPassengers() {
        return NumberOfPassengers;
    }
    
    public void addflight(Flight F){       
                                                    /*this function is to add an object to tha array list Flight by passing 
                                                        the object you want to add and check that it is not exist 
                                                                if not exist add the pbject to array */
            Flights.add(F);
            System.out.println("the flight added correctly");
        
    }
    
    public void AddFlight (Flight F){
                                            /*this function is to add an object to tha array list Flight by passing 
                                            the object but empty object that crated in the main and bass it then get 
                                            all values from user and set it into the object then add the object*/
        System.out.println("Please enter the Flight Number : ");
         F_Num=sc.nextInt();
         F.setFlightNumber(F_Num);
        System.out.println("Enter the Flight Capacity : ");
         F_Capacity=sc.nextInt();
        F.setFlightCapacity(F_Capacity);
        System.out.println("Enter the Flight Number of passengers : ");
         F_Passengers=sc.nextInt();
        F.setNumberOfPassengers(F_Passengers);
        System.out.println("Enter the  Start Point : ");
         S_Point=sc.nextLine();
        F.setStartPoint(S_Point);
        sc.nextLine();
        System.out.println("Enter the  Destination : ");
         Dist=sc.nextLine();
        F.setDestination(Dist);
        System.out.println("Enter the Duration : ");
         Dur=sc.nextLine();
        F.setDuration(Dur);
        System.out.println("Enter the Leave Date : ");
         L_Date=sc.nextLine();
        F.setLeaveDate(L_Date);
        System.out.println("Enter the Leave Time : ");
         L_Time=sc.nextLine();
        F.setLeaveTime(L_Time);
        System.out.println("Enter the Arrive Date : ");
         A_Date=sc.nextLine();
        F.setArriveDate(A_Date);
        System.out.println("Enter the Arrive Time : ");
         A_Time=sc.nextLine();
        F.setArriveTime(A_Time);
        System.out.println("Enter the Airport Code : ");
         A_P_Code=sc.nextLine();
        F.setAirportCode(A_P_Code);
        Flights.add(F);
        System.out.println("The Flight Added successfully");
    }
    
    public Flight RemoveFllight(int FlightNumber){    /* this function is to delete an object from the array by get from user the  Flight number 
                                                           that he want to delete then search for this object and check if the object exit 
                                                            then deleta it from the array*/
        for(int i=0; i < Flights.size(); i++){
            Flights.get(i);
            if (Flights.get(i).getFlightNumber() == FlightNumber) { 
                System.out.println("Flight deleted successfully");
                return Flights.remove(i);
            }
        }
        System.out.println("The flight does not exist");
        return null;
    }
    
    public static Flight GetFlight(int FlightNumber){  /* this function is to search for a specific object in the array by passenger id
                                                                and return this object if found and null if not found*/
        for(int i=0; i<Flights.size(); i++){
            
            if (Flights.get(i).getFlightNumber() == FlightNumber){
                System.out.println("The flight number : "+FlightNumber+" exists" );
                return Flights.get(i);
            }
        }
        System.out.println("The flight number : "+FlightNumber+" does not exit ");
        return null;
    }
    public boolean SearchFlight(int FlightNumber){ /* this function is to search for a specific Flight in the array by Flight number
                                                                and return true if found and false if not found*/
        for(int i=0; i<Flights.size(); i++){
            
            if (Flights.get(i).getFlightNumber() == FlightNumber){
                System.out.println("The flight number : "+FlightNumber+" exists" );
                return true;
            }
        }
        System.out.println("The flight number : "+FlightNumber+" does not exit ");
        return false;
    }
    
    public boolean IsFull(){      /* this function is to check if the array is full or noy by compare the number of passengers with array size  */
        if(NumberOfPassengers >= FlightCapacity){
            System.out.println("the flight is full");
            return true;
        }
        return false;
    }
    
    public void EditFlight(int FlightNumber){
        boolean b = true;
        for(int i=0;i<Flights.size();i++){
            if(Flights.get(i).getFlightNumber()== FlightNumber ){
                Flight EditF = new Flight();
                System.out.println("you can edit now");
                System.out.println("enter the new Flight Number : ");
                F_Num= sc.nextInt();
                EditF.setFlightNumber(F_Num);
                System.out.println("Enter the New Flight Capacity : ");
                F_Capacity=sc.nextInt();
                EditF.setFlightCapacity(F_Capacity);
                System.out.println("Enter the new Flight Number of passengers : ");
                F_Passengers=sc.nextInt();
                EditF.setNumberOfPassengers(F_Passengers);
                System.out.println("Enter the new Start Point : ");
                sc.nextLine();
                S_Point=sc.nextLine();
                EditF.setStartPoint(S_Point);
                System.out.println("Enter the new Destination : ");
                Dist=sc.nextLine();
                EditF.setDestination(Dist);
                System.out.println("Enter the new Duration : ");
                Dur=sc.nextLine();
                EditF.setDuration(Dur);
                System.out.println("Enter the new Leave Date : ");
                L_Date=sc.nextLine();
                EditF.setLeaveDate(L_Date);
                System.out.println("Enter the new Leave Time : ");
                L_Time=sc.nextLine();
                EditF.setLeaveTime(L_Time);
                System.out.println("Enter the new Arrive Date : ");
                A_Date=sc.nextLine();
                EditF.setArriveDate(A_Date);
                System.out.println("Enter the new Arrive Time : ");
                A_Time=sc.nextLine();
                EditF.setArriveTime(A_Time);
                System.out.println("Enter the new Airport Code : ");
                A_P_Code=sc.nextLine();
                EditF.setAirportCode(A_P_Code);
                System.out.println("The Flight information updated successfully");
                Flights.set(i, EditF);
                b = false;
            }
            
        }
         
        if(b){
            System.out.println("cannot update, the fligt does not exist");
            System.out.println("Try to add a new flight");

        }
    }  
    public boolean IsEmpty(){ /* this function is to check if the array is full or noy by checkthe number of passengers is graeter than 0 or not */
        if(NumberOfPassengers<=0){
            System.out.println("The flight is empty");
            return true;
        }
        return false;
    }
    @Override
    public String toString() {
        return "Flight{" + "FlightNumber=" + FlightNumber + ", FlightCapacity=" + FlightCapacity + ", NumberOfPassengers=" + NumberOfPassengers + ", StartPoint=" + StartPoint + ", Destination=" + Destination + ", Duration=" + Duration + ", LeaveDate=" + LeaveDate + ", LeaveTime=" + LeaveTime + ", ArriveDate=" + ArriveDate + ", ArriveTime=" + ArriveTime + ", AirportCode=" + AirportCode + '}';
    }
}
