/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gui.project;
/**
 *
 * @author 20106
 */
import java.util.*;

public class Inquiry {
    private static ArrayList<Inquiry> arr = new ArrayList<>();//it is static to share the same array over all objects
    private int ID;
    private String InquiryTitle;
    private String InquiryType; 
    private int InquiryDate; 
    private String InquiryDescription;
//constructors to intialize the attributes
    public Inquiry(String InquiryTitle1, int ID1) {
    }
//Defulat constructors 
    public Inquiry() {
    }
//constructors to intialize the attributes

    public Inquiry(int ID, String InquiryTitle, String InquiryType, int InquiryDate, String InquiryDescription) {
        this.ID = ID;
        this.InquiryTitle = InquiryTitle;
        this.InquiryType = InquiryType;
        this.InquiryDate = InquiryDate;
        this.InquiryDescription = InquiryDescription;
    }
    //setters and getters for the private attributes
    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getInquiryTitle() {
        return InquiryTitle;
    }

    public void setInquiryTitle(String InquiryTitle) {
        this.InquiryTitle = InquiryTitle;
    }

    public String getInquiryType() {
        return InquiryType;
    }

    public void setInquiryType(String InquiryType) {
        this.InquiryType = InquiryType;
    }

    public int getInquiryDate() {
        return InquiryDate;
    }

    public void setInquiryDate(int InquiryDate) {
        this.InquiryDate = InquiryDate;
    }

    public String getInquiryDescription() {
        return InquiryDescription;
    }

    public void setInquiryDescription(String InquiryDescription) {
        this.InquiryDescription = InquiryDescription;
    } 

    public static ArrayList<Inquiry> getArr2() {//   getter for the  inquiries array
        return arr;
    }

//add inquiry function if the passenger want to add an inquiry 

    public void addInquiry( int ID, String InquiryTitle, String InquiryType, int InquiryDate, String InquiryDescription)//updatet that i added all parameters 
     {
        Inquiry inq1 = new Inquiry ( ID, InquiryTitle, InquiryType, InquiryDate,InquiryDescription);
        arr.add(inq1);
         System.out.println("your inquiry is added successfully");
     }
            
          // remove inquiry function if the passenger want to delete an inquiry that has been added
        
    public void removeInquiry(int ID)
     {
        boolean b = true;
        for (int i=0; i<arr.size(); i++)
        {
            Inquiry n = arr.get(i);            
            if (n.getID() == ID){
                n.removeInquiry(i);
                System.out.println("inquiry deleted successfully");
                b =false;
            }
            if(b)
                System.out.println("the iquiry is not found");

        }    
    }     
}


