/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gui.project;
/**
 *
 * @author 20106
 */
import java.util.*;

public class Passenger extends Person {
    private int PassengerID;                                                  /*  this is the attributes of the class */
    private static int Count= 0;
    public static ArrayList <Passenger> Passengers = new ArrayList<>();    /* array list for all passengers account*/
    public ArrayList <Booking> History = new ArrayList<>();                 /* array list for each passenger Bookings */
    //constructors to intialize the attributes
    public Passenger(String Email, String Password, Long NationalID, String FullName, int age, String gender, int PhoneNumber) {
        super(NationalID, FullName, age, gender, PhoneNumber, Email, Password);
        Count++;                                            /* this count to make the passenger id unique by add 1 for every object created*/
        this.PassengerID = Count;
    }  
    //Defulat constructors 
    public Passenger() {
        Count++;                                            /* this count to make the passenger id unique by add 1 for every object created*/
        this.PassengerID = Count;
    }
    
     
    
    
    
    

   @Override
    public void AddAcc(Person P){               
        Passenger Pass=(Passenger) P;                         /* this function is to add account for the array list Passengers by get all values
                                                               from the user and set this valus in object and add this object to the array*/
        Scanner input = new Scanner(System.in); 
        System.out.println("enter your mail");
        input.nextLine();
        String email=input.nextLine();
        System.out.println("enter your Password");
        String password=input.nextLine();
        System.out.println("enter your NationalID");
        long NID=input.nextLong();
        System.out.println("enter your FullName");
        input.nextLine();
        String FNAME=input.nextLine();
        System.out.println("enter your age");
        int A=input.nextInt();
        System.out.println("enter your gender");
        String G =input.next();
        System.out.println("enter your PhoneNumber");
        int PhoneNUM=input.nextInt();
        Pass.setAge(A);
        Pass.setFullName(FNAME);
        Pass.setGender(G);
        Pass.setNationalID(NID);
        Pass.setPhoneNumber(PhoneNUM);
        Pass.setEmail(email);
        Pass.setPassword(password);
        Passengers.add(Pass);
        System.out.println("added successfully");

    }   
        
   @Override
    public void RemoveAcc(int passID){                  /* this function is to delete an object from the array by get from user the id 
                                                           that he want to delete then search for this object and check if the object  exit 
                                                            then deleta it from the array*/
        boolean b = true;
        for(int i=0;i<Passengers.size();i++){
            if (Passengers.get(i).Equal(passID)){
                System.out.println(Passengers.get(i));
                Passengers.remove(i);
                System.out.println("removed successfully");
                b=false;
            }
        }
        if(b){
            System.out.println("Not found");
        }
        
    }
    public static Passenger SearchforPassenger(int passID) { /* this function is to search for a specific object in the array by passenger id
                                                                and return this object if found and null if not found*/
        for ( int i=0;i<Passengers.size();i++) {
            if (Passengers.get(i).Equal(passID)) {
                System.out.println(Passengers.get(i));
                return Passengers.get(i); 
            }                
        }
        return null;       
    }
    public static boolean CheckPassenger(int passID) {  /* this function is to search for a specific Passenger in the array by passenger id                                                                and return  true if found and false if not*/
        for ( int i=0;i<Passengers.size();i++) {
            if (Passengers.get(i).Equal(passID)) {
                System.out.println(Passengers.get(i));
                return true; 
            }                
        }
        return false;       
    }
    public boolean Equal(int ID) { /* this function is just to check the equality between two id and return true if equal*/
        if (this.PassengerID == ID )
            return true;
    else 
            return false;
    }
 
    public static void ManageAccount(int passID){  
                                /* this function is to manage your account by ask user for to enter the id of account that he wnat to intilais
                                and then search for this account and check if the object is exist
                                if found the user enter his updates if not found display not found  */
        boolean B = true;
        for ( int i=0;i<Passengers.size();i++) {
            if (Passengers.get(i).Equal(passID)){
                while(B){
                    System.out.println("1/ ubdate Email ");        
                    System.out.println("2/ ubdate Password ");
                    System.out.println("3/ ubdate Passenger ID ");
                    System.out.println("4/ ubdate Phone number ");
                    System.out.println("0/ Exit ");
                    System.out.println("which function do you want");
                    Scanner input = new Scanner(System.in);
                    int Num = input.nextInt();
                    if (Num==1){
                    System.out.println("Enter the new email");
                        String mail = input.nextLine();
                        input.nextLine();
                        Passengers.get(i).setEmail(mail);
                        System.out.println("added successfully");
                    }
                    else if (Num==2){
                        System.out.println("Enter the new Password");
                        String password = input.nextLine();
                        input.nextLine();
                        Passengers.get(i).setPassword(password);
                        System.out.println("added successfully");
                    }
                    else if (Num==3){
                        System.out.println("Enter the new Passenger ID");
                        int ID = input.nextInt();
                        input.nextLine();
                        Passengers.get(i).setPassengerID(ID);
                        System.out.println("added successfully");

                    }
                    else if (Num==4){
                        System.out.println("Enter the new phone number");
                        long p = input.nextLong();
                        input.nextLine();
                        Passengers.get(i).setPhoneNumber(p);
                        System.out.println("added successfully");
                        }
                    else if (Num==0){
                        B = false;
                    }
                    else 
                            System.out.println("invalid number");
                }
                break;
            }
        }
        if(B)
        System.out.println("the account not in the system");    
    }
    @Override
    /* setters and getters*/
    public void display(){ 
        System.out.println("this is the list of Passengers");
        System.out.println(Passengers);         
    }
   
    public int getPassengerID() {
        return PassengerID;
    }

    public void setPassengerID(int PassengerID) {
        this.PassengerID = PassengerID;
    }
  
}
